export { default as PrototypeList } from './prototype-list/prototype-list';
export { default as PrototypeDetail } from './prototype-detail/prototype-detail';