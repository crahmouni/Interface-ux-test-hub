export { default as HomePage } from './home';
export { default as SearchPage } from './search';
export { default as PrototypeDetailPage } from './prototype-detail';
export { default as LoginPage } from './login';
export { default as CreatePrototypePage } from './creat-prototype';