const dayjs = require('dayjs');

module.exports =  dayjs;